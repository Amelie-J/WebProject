Groupe composé de:
JOND Amélie
TROUBAT Bastien